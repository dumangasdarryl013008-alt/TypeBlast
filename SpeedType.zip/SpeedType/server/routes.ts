import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { insertTypingTestSchema } from "@shared/schema";

export async function registerRoutes(app: Express): Promise<Server> {
  
  // Get text content for typing test
  app.get("/api/text-content/:difficulty/:testType", async (req, res) => {
    try {
      const { difficulty, testType } = req.params;
      const content = await storage.getTextContent(difficulty, testType);
      
      if (content.length === 0) {
        return res.status(404).json({ message: "No content found for specified parameters" });
      }
      
      // Return a random text from available content
      const randomContent = content[Math.floor(Math.random() * content.length)];
      res.json(randomContent);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch text content" });
    }
  });

  // Submit typing test results
  app.post("/api/typing-test", async (req, res) => {
    try {
      const validatedData = insertTypingTestSchema.parse(req.body);
      const test = await storage.createTypingTest(validatedData);
      res.json(test);
    } catch (error) {
      res.status(400).json({ message: "Invalid test data" });
    }
  });

  // Get user's test history (optional, for future features)
  app.get("/api/typing-tests/:userId", async (req, res) => {
    try {
      const { userId } = req.params;
      const tests = await storage.getUserTests(userId);
      res.json(tests);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch test history" });
    }
  });

  // Get leaderboard - top scores across all players
  app.get("/api/leaderboard", async (req, res) => {
    try {
      const { difficulty, testType, limit = 10 } = req.query;
      const leaderboard = await storage.getLeaderboard(
        difficulty as string, 
        testType as string, 
        parseInt(limit as string) || 10
      );
      res.json(leaderboard);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch leaderboard" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
