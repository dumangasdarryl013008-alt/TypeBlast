import { type User, type InsertUser, type TypingTest, type InsertTypingTest, type TextContent, type InsertTextContent } from "@shared/schema";
import { randomUUID } from "crypto";

export interface IStorage {
  getUser(id: string): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  
  createTypingTest(test: InsertTypingTest): Promise<TypingTest>;
  getUserTests(userId: string): Promise<TypingTest[]>;
  getLeaderboard(difficulty?: string, testType?: string, limit?: number): Promise<TypingTest[]>;
  
  getTextContent(difficulty: string, testType: string): Promise<TextContent[]>;
  createTextContent(content: InsertTextContent): Promise<TextContent>;
}

export class MemStorage implements IStorage {
  private users: Map<string, User>;
  private typingTests: Map<string, TypingTest>;
  private textContent: Map<string, TextContent>;

  constructor() {
    this.users = new Map();
    this.typingTests = new Map();
    this.textContent = new Map();
    
    // Initialize with sample text content
    this.initializeTextContent();
  }

  private async initializeTextContent() {
    const sampleTexts = [
      // Easy words
      {
        difficulty: "easy",
        testType: "words",
        content: "the and for are but not you all can had her was one our out day get has him his how man new now old see two way who boy did its let put say she too use"
      },
      // Easy sentences
      {
        difficulty: "easy", 
        testType: "sentences",
        content: "I love to type. The cat is on the mat. We are happy today. The sun is bright. Birds sing in the trees. This is a simple test. Practice makes perfect every day."
      },
      // Easy numbers
      {
        difficulty: "easy",
        testType: "numbers",
        content: "123 456 789 012 345 678 901 234 567 890 111 222 333 444 555 666 777 888 999 000 147 258 369 159 753 482 617 394 825 076"
      },
      // Medium words
      {
        difficulty: "medium",
        testType: "words", 
        content: "quickly brown jumped through between different against important because something experience question understand development technology computer science knowledge business management success achievement"
      },
      // Medium sentences
      {
        difficulty: "medium", 
        testType: "sentences",
        content: "The quick brown fox jumps over the lazy dog. This pangram contains every letter of the alphabet and is commonly used for typing practice. It helps improve finger dexterity and keyboard familiarity through repetitive motion."
      },
      // Medium numbers
      {
        difficulty: "medium",
        testType: "numbers",
        content: "12.34 567.89 1,234 5,678 90.12 345.67 891,023 456.78 901,234 567.89 123.45 678.90 12,345 67.89 901,234.56 789.01 234.56"
      },
      // Hard words
      {
        difficulty: "hard",
        testType: "words",
        content: "extraordinary incomprehensible predominantly circumstances responsibility characteristics implementation optimization configuration administration infrastructure architecture development environmental technological"
      },
      // Hard sentences
      {
        difficulty: "hard",
        testType: "sentences", 
        content: "JavaScript is a versatile programming language that enables interactive web development. Modern frameworks like React, Vue, and Angular have revolutionized how developers build user interfaces and manage application state effectively."
      },
      // Hard numbers
      {
        difficulty: "hard",
        testType: "numbers",
        content: "3.14159 2.71828 1.41421 1.73205 2.23607 299,792,458 6.02214 9.10938 1.60218 1.38065 6.67408 1.05457 8.85419 4.13567 1.25664"
      }
    ];

    for (const text of sampleTexts) {
      await this.createTextContent(text);
    }
  }

  async getUser(id: string): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = randomUUID();
    const user: User = { ...insertUser, id };
    this.users.set(id, user);
    return user;
  }

  async createTypingTest(insertTest: InsertTypingTest): Promise<TypingTest> {
    const id = randomUUID();
    const test: TypingTest = { 
      ...insertTest,
      userId: insertTest.userId ?? null,
      playerName: insertTest.playerName ?? null,
      id, 
      completedAt: new Date()
    };
    this.typingTests.set(id, test);
    return test;
  }

  async getUserTests(userId: string): Promise<TypingTest[]> {
    return Array.from(this.typingTests.values()).filter(
      (test) => test.userId === userId
    );
  }

  async getLeaderboard(difficulty?: string, testType?: string, limit = 10): Promise<TypingTest[]> {
    let tests = Array.from(this.typingTests.values());
    
    // Filter by difficulty if specified
    if (difficulty) {
      tests = tests.filter(test => test.difficulty === difficulty);
    }
    
    // Filter by test type if specified  
    if (testType) {
      tests = tests.filter(test => test.testType === testType);
    }
    
    // Sort by WPM (highest first), then by accuracy (highest first)
    tests.sort((a, b) => {
      if (b.wpm !== a.wpm) {
        return b.wpm - a.wpm;
      }
      return b.accuracy - a.accuracy;
    });
    
    // Return only the top results
    return tests.slice(0, limit);
  }

  async getTextContent(difficulty: string, testType: string): Promise<TextContent[]> {
    // Generate randomized content instead of using static content
    const content = this.generateRandomizedContent(difficulty, testType);
    return [content];
  }

  private generateRandomizedContent(difficulty: string, testType: string): TextContent {
    const id = randomUUID();
    let content = "";

    if (testType === "words") {
      content = this.generateRandomWords(difficulty);
    } else if (testType === "sentences") {
      content = this.generateRandomSentences(difficulty);
    } else if (testType === "numbers") {
      content = this.generateRandomNumbers(difficulty);
    }

    return {
      id,
      difficulty,
      testType,
      content,
      isActive: true
    };
  }

  private generateRandomWords(difficulty: string): string {
    const wordPools = {
      easy: [
        // Short words 3-6 characters
        "the", "and", "for", "are", "but", "not", "you", "all", "can", "had", "her", "was", "one", "our", "out", "day", "get", "has", "him", "his", "how", "man", "new", "now", "old", "see", "two", "way", "who", "boy", "did", "its", "let", "put", "say", "she", "too", "use", "cat", "dog", "run", "jump", "walk", "talk", "play", "work", "home", "time", "life", "love", "make", "take", "come", "give", "good", "great", "small", "big", "first", "last", "long", "right", "left", "high", "low", "hot", "cold", "fast", "slow", "easy", "hard", "open", "close", "start", "stop", "help", "find", "tell", "ask", "know", "think", "feel", "look", "turn", "keep", "move", "live", "show", "hear", "read", "write", "learn", "teach", "study", "book", "page", "word", "line", "story", "music", "song", "game", "sport", "food", "water", "house", "room", "door", "table", "chair", "tree", "sun", "moon", "star", "wind", "rain", "fire", "earth", "sea", "river", "city", "town", "shop", "money", "friend", "mother", "father", "child", "girl", "woman", "person", "hand", "foot", "head", "face", "body", "heart", "mind", "idea", "plan", "hope", "wish", "dream", "smile", "laugh", "happy", "angry", "brave", "kind", "nice", "smart", "funny", "clean", "dirty", "rich", "poor", "young", "strong", "weak", "quiet", "loud", "calm", "busy", "free", "safe", "lost", "found", "ready", "done", "real", "true", "false", "sure", "maybe", "here", "there", "where", "when", "what", "while", "again", "also", "still", "just", "only", "even", "more", "less", "most", "best", "same", "other", "every", "each", "some", "many", "little", "much", "about", "near", "above", "below", "under", "over", "back", "down", "with", "from", "into", "onto", "like", "than", "very", "quite", "often", "today", "week", "month", "year", "april", "march"
      ],
      medium: [
        // Medium words 7-15 characters  
        "quickly", "through", "between", "different", "against", "important", "because", "something", "experience", "question", "understand", "development", "technology", "computer", "science", "knowledge", "business", "management", "success", "achievement", "education", "information", "communication", "organization", "administration", "professional", "international", "government", "community", "opportunity", "responsibility", "relationship", "environment", "philosophy", "psychology", "sociology", "economics", "mathematics", "statistics", "research", "analysis", "strategy", "planning", "decision", "solution", "problem", "challenge", "situation", "condition", "position", "direction", "attention", "intention", "prevention", "protection", "production", "construction", "destruction", "instruction", "introduction", "conclusion", "discussion", "explanation", "description", "prescription", "subscription", "transportation", "transformation", "translation", "accommodation", "recommendation", "consideration", "concentration", "demonstration", "presentation", "representation", "interpretation", "implementation", "coordination", "cooperation", "collaboration", "investigation", "negotiation", "registration", "recognition", "appreciation", "application", "qualification", "classification", "specification", "identification", "modification", "verification", "certification", "standardization", "optimization", "civilization", "globalization", "localization", "personalization", "customization", "modernization", "mechanization", "digitalization", "visualization", "realization", "actualization", "utilization", "maximization", "minimization", "synchronization", "initialization", "finalization", "capitalization"
      ],
      hard: [
        // Long words 16+ characters
        "constitutionalization", "internationalization", "institutionalization", "commercialization", "industrialization", "spiritualization", "materialization", "crystallization", "sterilization", "fertilization", "characterization", "categorization", "generalization", "specialization", "socialization", "nationalization", "rationalization", "reorganization", "decentralization", "centralization", "liberalization", "democratization", "authorization", "legalization", "legitimization", "normalization", "formalization", "conceptualization", "contextualization", "intellectualization", "externalization", "internalization", "popularization", "polarization", "summarization", "familiarization", "regularization", "singularization", "pluralization", "universalization", "particularization", "secularization", "irregularization", "computerization", "motorization", "theorization", "memorization", "prioritization", "randomization", "disorganization", "incomprehensible", "predominantly", "circumstances", "characteristics", "infrastructure", "environmental", "technological", "philosophical", "psychological", "sociological", "anthropological", "archaeological", "astronomical", "mathematical", "geographical", "physiological", "pathological", "neurological", "etymological", "terminological", "phenomenological", "epistemological", "ontological", "theological", "ideological", "teleological", "eschatological", "cosmological", "chronological", "mythological", "genealogical", "mineralogical", "meteorological", "seismological", "gerontological", "dermatological", "ophthalmological", "otolaryngological", "gastroenterological", "endocrinological", "rheumatological", "immunological", "hematological", "cardiological", "pulmonological", "nephrological", "gynecological", "interferometric", "refractometric", "densitometric", "microcalorimetric", "nanocalorimetric", "chronometric", "accelerometric", "magnetometric", "electrometric", "potentiometric", "amperometric", "voltammetric", "coulometric", "conductometric", "impedimetric", "dielectrometric", "piezoelectric", "ferroelectric", "pyroelectric", "thermoelectric", "photoelectric", "electrochemical", "mechanochemical", "macromolecular", "supramolecular", "intermolecular", "intramolecular", "multimolecular", "polymolecular", "biomolecular", "organometallic", "thermodynamic", "hydrodynamic", "aerodynamic", "electrodynamic", "magnetodynamic", "photodynamic", "psychodynamic", "sociodynamic", "pharmacodynamic", "toxicodynamic", "chromatodynamic"
      ]
    };

    const pool = wordPools[difficulty as keyof typeof wordPools] || wordPools.easy;
    const shuffled = [...pool].sort(() => Math.random() - 0.5);
    return shuffled.slice(0, 25 + Math.floor(Math.random() * 15)).join(" ");
  }

  private generateRandomSentences(difficulty: string): string {
    const sentenceTemplates = {
      easy: [
        ["I", "We", "You", "They", "The cat", "The dog", "My friend", "The teacher"],
        ["love", "like", "enjoy", "want", "need", "have", "see", "hear", "know", "think"],
        ["to play", "to read", "to write", "to sing", "to dance", "to run", "to walk", "good food", "nice music", "warm weather", "sunny days", "cool nights"],
        ["every day", "right now", "very much", "a lot", "sometimes", "often", "always", "never", "today", "tomorrow"]
      ],
      medium: [
        ["The experienced", "A professional", "Every successful", "Most dedicated", "An accomplished", "The determined"],
        ["developer", "manager", "teacher", "student", "researcher", "scientist", "artist", "musician", "writer", "athlete"],
        ["quickly learns", "carefully studies", "thoroughly understands", "effectively implements", "successfully completes", "consistently delivers"],
        ["complex projects", "challenging tasks", "important assignments", "difficult problems", "innovative solutions", "creative approaches"],
        ["through dedication", "with persistence", "using modern tools", "by following best practices", "while maintaining quality", "despite obstacles"]
      ],
      hard: [
        ["Contemporary", "Sophisticated", "Multidisciplinary", "Interdisciplinary", "Revolutionary", "Groundbreaking"],
        ["implementations", "methodologies", "technologies", "frameworks", "architectures", "paradigms", "algorithms", "protocols"],
        ["systematically", "comprehensively", "meticulously", "rigorously", "extensively", "fundamentally"],
        ["transform", "optimize", "revolutionize", "streamline", "enhance", "facilitate", "accelerate", "integrate"],
        ["organizational", "computational", "technological", "experimental", "theoretical", "practical", "empirical"],
        ["processes through", "systems via", "methodologies using", "approaches by", "solutions through"],
        ["advanced analytics", "machine learning", "artificial intelligence", "quantum computing", "distributed systems", "microservices architecture", "cloud-native solutions"]
      ]
    };

    const templates = sentenceTemplates[difficulty as keyof typeof sentenceTemplates] || sentenceTemplates.easy;
    const sentences = [];
    const numSentences = 3 + Math.floor(Math.random() * 4);

    for (let i = 0; i < numSentences; i++) {
      const sentence = templates.map(part => 
        part[Math.floor(Math.random() * part.length)]
      ).join(" ") + ".";
      sentences.push(sentence);
    }

    return sentences.join(" ");
  }

  private generateRandomNumbers(difficulty: string): string {
    const numbers = [];
    const count = 15 + Math.floor(Math.random() * 10);

    for (let i = 0; i < count; i++) {
      if (difficulty === "easy") {
        numbers.push(Math.floor(Math.random() * 1000).toString().padStart(3, '0'));
      } else if (difficulty === "medium") {
        const hasDecimal = Math.random() > 0.5;
        const hasComma = Math.random() > 0.7;
        
        if (hasDecimal) {
          const whole = Math.floor(Math.random() * 1000);
          const decimal = Math.floor(Math.random() * 100);
          numbers.push(`${whole}.${decimal.toString().padStart(2, '0')}`);
        } else if (hasComma) {
          const num = Math.floor(Math.random() * 100000);
          numbers.push(num.toLocaleString());
        } else {
          numbers.push(Math.floor(Math.random() * 10000).toString());
        }
      } else {
        const type = Math.floor(Math.random() * 4);
        
        if (type === 0) {
          // Scientific notation-like
          const base = (Math.random() * 9 + 1).toFixed(5);
          numbers.push(base);
        } else if (type === 1) {
          // Large numbers with commas
          const num = Math.floor(Math.random() * 1000000000);
          numbers.push(num.toLocaleString());
        } else if (type === 2) {
          // Decimal numbers
          const whole = Math.floor(Math.random() * 100);
          const decimal = Math.floor(Math.random() * 100000);
          numbers.push(`${whole}.${decimal.toString().padStart(5, '0')}`);
        } else {
          // Mixed format
          const num = (Math.random() * 1000).toFixed(Math.floor(Math.random() * 6));
          numbers.push(num);
        }
      }
    }

    return numbers.join(" ");
  }

  async createTextContent(insertContent: InsertTextContent): Promise<TextContent> {
    const id = randomUUID();
    const content: TextContent = { 
      ...insertContent, 
      id,
      isActive: true
    };
    this.textContent.set(id, content);
    return content;
  }
}

export const storage = new MemStorage();
