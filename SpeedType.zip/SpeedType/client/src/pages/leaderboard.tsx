import { useState, useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Label } from "@/components/ui/label";
import { Trophy, Medal, Award, User, Clock, Target, TrendingUp, Home, Keyboard } from "lucide-react";
import type { TypingTest } from "@shared/schema";
import { Link } from "wouter";

export default function Leaderboard() {
  const [selectedDifficulty, setSelectedDifficulty] = useState<string>("all");
  const [selectedTestType, setSelectedTestType] = useState<string>("all");

  // Fetch leaderboard data
  const { data: leaderboard = [], isLoading, error } = useQuery<TypingTest[]>({
    queryKey: ['/api/leaderboard', selectedDifficulty, selectedTestType],
    queryFn: async () => {
      const params = new URLSearchParams();
      if (selectedDifficulty !== "all") params.append("difficulty", selectedDifficulty);
      if (selectedTestType !== "all") params.append("testType", selectedTestType);
      params.append("limit", "20");

      const response = await fetch(`/api/leaderboard?${params}`);
      if (!response.ok) throw new Error("Failed to fetch leaderboard");
      return response.json();
    }
  });

  const getRankIcon = (index: number) => {
    switch (index) {
      case 0:
        return <Trophy className="h-8 w-8 text-yellow-500" data-testid="icon-first-place" />;
      case 1:
        return <Medal className="h-8 w-8 text-gray-400" data-testid="icon-second-place" />;
      case 2:
        return <Award className="h-8 w-8 text-orange-600" data-testid="icon-third-place" />;
      default:
        return (
          <div className="h-8 w-8 rounded-full bg-gray-100 dark:bg-gray-700 flex items-center justify-center text-sm font-bold text-gray-600 dark:text-gray-300" data-testid={`rank-${index + 1}`}>
            {index + 1}
          </div>
        );
    }
  };

  const getRankBgColor = (index: number) => {
    switch (index) {
      case 0:
        return "bg-gradient-to-r from-yellow-50 to-orange-50 dark:from-yellow-900/20 dark:to-orange-900/20 border-yellow-200 dark:border-yellow-700";
      case 1:
        return "bg-gradient-to-r from-gray-50 to-blue-50 dark:from-gray-800/50 dark:to-blue-900/20 border-gray-200 dark:border-gray-600";
      case 2:
        return "bg-gradient-to-r from-orange-50 to-red-50 dark:from-orange-900/20 dark:to-red-900/20 border-orange-200 dark:border-orange-700";
      default:
        return "bg-white dark:bg-gray-800 border-gray-200 dark:border-gray-700";
    }
  };

  if (error) {
    return (
      <div className="min-h-screen bg-gray-50 dark:bg-gray-900 py-8">
        <div className="max-w-4xl mx-auto px-4 text-center">
          <div className="text-red-500 dark:text-red-400">
            <p>Failed to load leaderboard</p>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-900">
      {/* Navigation Header */}
      <header className="bg-white dark:bg-gray-800 shadow-sm border-b border-gray-200 dark:border-gray-700">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center">
              <Keyboard className="text-primary text-2xl mr-3" />
              <h1 className="text-xl font-bold text-gray-900 dark:text-gray-100">TypeBlast</h1>
            </div>
            <div className="flex items-center space-x-4">
              <Link href="/">
                <Button variant="ghost" size="sm" data-testid="button-home">
                  <Home className="h-4 w-4" />
                  <span className="ml-2 hidden sm:inline">Home</span>
                </Button>
              </Link>
            </div>
          </div>
        </div>
      </header>

      {/* Title Section */}
      <div className="bg-white dark:bg-gray-800 shadow-sm border-b border-gray-200 dark:border-gray-700">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          <div className="text-center">
            <div className="flex justify-center mb-4">
              <Trophy className="h-12 w-12 text-primary" />
            </div>
            <h1 className="text-4xl font-bold text-gray-900 dark:text-gray-100 mb-4">Leaderboard</h1>
            <p className="text-lg text-gray-600 dark:text-gray-400">Top typing champions across all difficulties</p>
          </div>
        </div>
      </div>

      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Filters */}
        <Card className="p-6 mb-8">
          <h3 className="text-lg font-semibold text-gray-900 dark:text-gray-100 mb-4">Filter Results</h3>
          <div className="grid md:grid-cols-2 gap-6">
            {/* Difficulty Filter */}
            <div>
              <Label className="text-sm font-medium text-gray-700 dark:text-gray-300 mb-3 block">
                Difficulty Level
              </Label>
              <RadioGroup
                value={selectedDifficulty}
                onValueChange={setSelectedDifficulty}
                data-testid="radio-difficulty-filter"
              >
                <div className="flex items-center space-x-2">
                  <RadioGroupItem value="all" id="all-difficulty" />
                  <Label htmlFor="all-difficulty">All Levels</Label>
                </div>
                <div className="flex items-center space-x-2">
                  <RadioGroupItem value="easy" id="easy-difficulty" />
                  <Label htmlFor="easy-difficulty">Easy</Label>
                </div>
                <div className="flex items-center space-x-2">
                  <RadioGroupItem value="medium" id="medium-difficulty" />
                  <Label htmlFor="medium-difficulty">Medium</Label>
                </div>
                <div className="flex items-center space-x-2">
                  <RadioGroupItem value="hard" id="hard-difficulty" />
                  <Label htmlFor="hard-difficulty">Hard</Label>
                </div>
              </RadioGroup>
            </div>

            {/* Test Type Filter */}
            <div>
              <Label className="text-sm font-medium text-gray-700 dark:text-gray-300 mb-3 block">
                Test Type
              </Label>
              <RadioGroup
                value={selectedTestType}
                onValueChange={setSelectedTestType}
                data-testid="radio-test-type-filter"
              >
                <div className="flex items-center space-x-2">
                  <RadioGroupItem value="all" id="all-type" />
                  <Label htmlFor="all-type">All Types</Label>
                </div>
                <div className="flex items-center space-x-2">
                  <RadioGroupItem value="words" id="words-type" />
                  <Label htmlFor="words-type">Words</Label>
                </div>
                <div className="flex items-center space-x-2">
                  <RadioGroupItem value="sentences" id="sentences-type" />
                  <Label htmlFor="sentences-type">Sentences</Label>
                </div>
                <div className="flex items-center space-x-2">
                  <RadioGroupItem value="numbers" id="numbers-type" />
                  <Label htmlFor="numbers-type">Numbers</Label>
                </div>
              </RadioGroup>
            </div>
          </div>
        </Card>

        {/* Leaderboard */}
        {isLoading ? (
          <div className="space-y-4" data-testid="loading-leaderboard">
            {[...Array(10)].map((_, i) => (
              <Card key={i} className="p-6 animate-pulse">
                <div className="flex items-center space-x-4">
                  <div className="h-8 w-8 bg-gray-200 dark:bg-gray-700 rounded-full"></div>
                  <div className="flex-1 space-y-2">
                    <div className="h-4 bg-gray-200 dark:bg-gray-700 rounded w-1/4"></div>
                    <div className="h-3 bg-gray-200 dark:bg-gray-700 rounded w-1/2"></div>
                  </div>
                  <div className="h-6 w-16 bg-gray-200 dark:bg-gray-700 rounded"></div>
                </div>
              </Card>
            ))}
          </div>
        ) : leaderboard.length === 0 ? (
          <Card className="p-12 text-center">
            <Trophy className="h-16 w-16 text-gray-300 dark:text-gray-600 mx-auto mb-4" />
            <h3 className="text-xl font-semibold text-gray-900 dark:text-gray-100 mb-2">No Results Found</h3>
            <p className="text-gray-600 dark:text-gray-400">
              No typing tests found for the selected filters. Try a different combination or take a typing test to appear on the leaderboard!
            </p>
          </Card>
        ) : (
          <div className="space-y-4" data-testid="leaderboard-list">
            {leaderboard.map((test, index) => (
              <Card
                key={test.id}
                className={`p-6 transition-all hover:shadow-lg ${getRankBgColor(index)}`}
                data-testid={`leaderboard-entry-${index + 1}`}
              >
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-4">
                    {getRankIcon(index)}
                    
                    <div className="flex items-center space-x-3">
                      <div className="h-10 w-10 bg-gray-200 dark:bg-gray-700 rounded-full flex items-center justify-center">
                        <User className="h-5 w-5 text-gray-600 dark:text-gray-400" />
                      </div>
                      <div>
                        <h4 className="font-semibold text-gray-900 dark:text-gray-100" data-testid={`player-name-${index + 1}`}>
                          {test.playerName || "Anonymous Player"}
                        </h4>
                        <div className="flex items-center space-x-4 text-sm text-gray-600 dark:text-gray-400">
                          <span className="capitalize">{test.difficulty}</span>
                          <span>•</span>
                          <span className="capitalize">{test.testType}</span>
                          <span>•</span>
                          <div className="flex items-center space-x-1">
                            <Clock className="h-3 w-3" />
                            <span>{test.duration}s</span>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>

                  <div className="flex items-center space-x-6">
                    <div className="text-center">
                      <div className="flex items-center space-x-1 text-2xl font-bold text-primary" data-testid={`wpm-${index + 1}`}>
                        <TrendingUp className="h-5 w-5" />
                        <span>{Math.round(test.wpm)}</span>
                      </div>
                      <div className="text-xs text-gray-500 dark:text-gray-400">WPM</div>
                    </div>
                    
                    <div className="text-center">
                      <div className="flex items-center space-x-1 text-xl font-semibold text-green-600 dark:text-green-400" data-testid={`accuracy-${index + 1}`}>
                        <Target className="h-4 w-4" />
                        <span>{Math.round(test.accuracy)}%</span>
                      </div>
                      <div className="text-xs text-gray-500 dark:text-gray-400">Accuracy</div>
                    </div>

                    <div className="text-center">
                      <div className="text-lg font-medium text-gray-700 dark:text-gray-300" data-testid={`errors-${index + 1}`}>
                        {test.errorCount}
                      </div>
                      <div className="text-xs text-gray-500 dark:text-gray-400">Errors</div>
                    </div>
                  </div>
                </div>

                {index < 3 && (
                  <div className="mt-4 pt-4 border-t border-gray-200 dark:border-gray-600">
                    <div className="text-sm text-gray-600 dark:text-gray-400">
                      <strong>Characters:</strong> {test.correctCharacters}/{test.totalCharacters} • 
                      <strong> Completed:</strong> {test.completedAt ? new Date(test.completedAt).toLocaleDateString() : "N/A"}
                    </div>
                  </div>
                )}
              </Card>
            ))}
          </div>
        )}

        {leaderboard.length > 0 && (
          <div className="mt-8 text-center">
            <p className="text-sm text-gray-600 dark:text-gray-400">
              Showing top {leaderboard.length} results • Rankings update in real-time
            </p>
          </div>
        )}
      </main>
    </div>
  );
}