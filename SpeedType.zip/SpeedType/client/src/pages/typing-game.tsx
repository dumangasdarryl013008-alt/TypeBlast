import { useState, useEffect, useRef, useCallback } from "react";
import { useMutation, useQuery } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { Textarea } from "@/components/ui/textarea";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { Keyboard, Settings, UserCircle, Play, RotateCcw, Trophy, Share, Plus, CheckCircle, Info, Lightbulb, Camera, Download } from "lucide-react";
import { Link } from "wouter";
import html2canvas from "html2canvas";

interface GameStats {
  wpm: number;
  accuracy: number;
  errors: number;
  totalCharacters: number;
  correctCharacters: number;
  timeElapsed: number;
}

interface TextContent {
  id: string;
  content: string;
  difficulty: string;
  testType: string;
}

interface GameSettings {
  difficulty: "easy" | "medium" | "hard";
  testType: "words" | "sentences" | "numbers";
  duration: number;
}

interface PopupNotification {
  id: number;
  value: number;
  type: "bonus" | "penalty";
}

export default function TypingGame() {
  const { toast } = useToast();
  
  // Game state
  const [gameSettings, setGameSettings] = useState<GameSettings>({
    difficulty: "easy",
    testType: "words", 
    duration: 60
  });
  
  const [gameState, setGameState] = useState<"setup" | "playing" | "finished">("setup");
  const [textToType, setTextToType] = useState("");
  const [userInput, setUserInput] = useState("");
  const [currentCharIndex, setCurrentCharIndex] = useState(0);
  const [timeRemaining, setTimeRemaining] = useState(60);
  const [gameStats, setGameStats] = useState<GameStats>({
    wpm: 0,
    accuracy: 100,
    errors: 0,
    totalCharacters: 0,
    correctCharacters: 0,
    timeElapsed: 0
  });
  const [showResults, setShowResults] = useState(false);
  const [startTime, setStartTime] = useState<Date | null>(null);
  const [showSettings, setShowSettings] = useState(false);
  const [playerName, setPlayerName] = useState("");
  
  // Combo system state
  const [combo, setCombo] = useState(0);
  const [lastWordIndex, setLastWordIndex] = useState(0);
  const [bonusTimeGained, setBonusTimeGained] = useState(0);
  const [actualTimeElapsed, setActualTimeElapsed] = useState(0);
  
  // Popup notifications state
  const [popupNotifications, setPopupNotifications] = useState<PopupNotification[]>([]);
  const notificationIdRef = useRef(0);
  
  const timerRef = useRef<NodeJS.Timeout | null>(null);
  const inputRef = useRef<HTMLTextAreaElement>(null);
  const resultsRef = useRef<HTMLDivElement>(null);
  
  // Add popup notification
  const addPopupNotification = (value: number, type: "bonus" | "penalty") => {
    const id = notificationIdRef.current++;
    setPopupNotifications(prev => [...prev, { id, value, type }]);
    
    // Remove notification after animation
    setTimeout(() => {
      setPopupNotifications(prev => prev.filter(n => n.id !== id));
    }, 2000);
  };

  // Fetch text content
  const { data: textContent, refetch: refetchText } = useQuery<TextContent>({
    queryKey: ['/api/text-content', gameSettings.difficulty, gameSettings.testType],
    enabled: false
  });

  // Submit test results
  const submitTestMutation = useMutation({
    mutationFn: async (testData: any) => {
      const response = await apiRequest('POST', '/api/typing-test', testData);
      return response.json();
    },
    onSuccess: () => {
      // Invalidate leaderboard cache to show updated results
      queryClient.invalidateQueries({ queryKey: ['/api/leaderboard'] });
      
      toast({
        title: "Test Results Saved",
        description: "Your typing test results have been recorded."
      });
    },
    onError: () => {
      toast({
        title: "Save Failed", 
        description: "Could not save test results.",
        variant: "destructive"
      });
    }
  });

  // Timer logic
  useEffect(() => {
    if (gameState === "playing" && timeRemaining > 0) {
      timerRef.current = setTimeout(() => {
        setTimeRemaining(prev => prev - 1);
      }, 1000);
    } else if (timeRemaining === 0 && gameState === "playing") {
      finishGame();
    }

    return () => {
      if (timerRef.current) {
        clearTimeout(timerRef.current);
      }
    };
  }, [gameState, timeRemaining]);

  // Calculate WPM and accuracy in real-time
  const calculateStats = useCallback(() => {
    if (!startTime || gameState !== "playing") return;

    const currentTime = Date.now();
    const realTimeElapsed = Math.round((currentTime - startTime.getTime()) / 1000);
    const timeElapsedMinutes = (currentTime - startTime.getTime()) / 60000;
    const wordsTyped = userInput.trim().split(/\s+/).length;
    const wpm = timeElapsedMinutes > 0 ? Math.round(wordsTyped / timeElapsedMinutes) : 0;
    
    let correctChars = 0;
    let totalChars = Math.max(userInput.length, 1);
    
    for (let i = 0; i < Math.min(userInput.length, textToType.length); i++) {
      if (userInput[i] === textToType[i]) {
        correctChars++;
      }
    }
    
    const accuracy = Math.round((correctChars / totalChars) * 100);
    const errors = totalChars - correctChars;

    // Update actual time elapsed (pure typing time)
    setActualTimeElapsed(realTimeElapsed);

    setGameStats({
      wpm,
      accuracy,
      errors,
      totalCharacters: totalChars,
      correctCharacters: correctChars,
      timeElapsed: realTimeElapsed // This is the pure time, not affected by bonuses
    });
  }, [userInput, textToType, startTime, gameState]);

  useEffect(() => {
    if (gameState === "playing") {
      calculateStats();
      
      // Auto-finish game when all text is typed
      if (userInput.length >= textToType.length && textToType.length > 0) {
        finishGame();
      }
    }
  }, [userInput, calculateStats, textToType.length, gameState]);

  const startGame = async () => {
    try {
      const result = await refetchText();
      if (result.data) {
        setTextToType(result.data.content);
        setGameState("playing");
        setUserInput("");
        setCurrentCharIndex(0);
        setTimeRemaining(gameSettings.duration);
        setStartTime(new Date());
        setCombo(0);
        setLastWordIndex(0);
        setBonusTimeGained(0);
        setActualTimeElapsed(0);
        
        // Focus input
        setTimeout(() => {
          inputRef.current?.focus();
        }, 100);
      }
    } catch (error) {
      toast({
        title: "Error",
        description: "Could not load typing text. Please try again.",
        variant: "destructive"
      });
    }
  };

  const finishGame = () => {
    setGameState("finished");
    setShowResults(true);
    
    // Submit results
    const testData = {
      difficulty: gameSettings.difficulty,
      testType: gameSettings.testType,
      duration: gameSettings.duration,
      wpm: gameStats.wpm,
      accuracy: gameStats.accuracy,
      totalCharacters: gameStats.totalCharacters,
      correctCharacters: gameStats.correctCharacters,
      errorCount: gameStats.errors,
      userId: null, // Optional for guest users
      playerName: playerName.trim() || null // Use provided name or null for anonymous
    };
    
    submitTestMutation.mutate(testData);
  };

  const resetGame = () => {
    setGameState("setup");
    setUserInput("");
    setCurrentCharIndex(0);
    setShowResults(false);
    setStartTime(null);
    setCombo(0);
    setLastWordIndex(0);
    setBonusTimeGained(0);
    setActualTimeElapsed(0);
    setGameStats({
      wpm: 0,
      accuracy: 100,
      errors: 0,
      totalCharacters: 0,
      correctCharacters: 0,
      timeElapsed: 0
    });
  };

  const handleInputChange = (value: string) => {
    if (gameState !== "playing") return;
    
    setUserInput(value);
    setCurrentCharIndex(value.length);
    
    // Check for word completion and combo system
    checkWordCompletion(value);
  };
  
  const checkWordCompletion = (input: string) => {
    if (!textToType) return;
    
    // Find all word boundaries (spaces) in the target text
    const wordBoundaries = [];
    for (let i = 0; i < textToType.length; i++) {
      if (textToType[i] === ' ') {
        wordBoundaries.push(i);
      }
    }
    
    // Check if we've completed a word
    for (const boundary of wordBoundaries) {
      if (boundary > lastWordIndex && input.length > boundary) {
        // Check if the word up to this boundary is correct
        const wordText = textToType.substring(lastWordIndex, boundary + 1);
        const userText = input.substring(lastWordIndex, boundary + 1);
        
        if (wordText === userText) {
          // Word completed correctly - increment combo and add bonus time
          const newCombo = combo + 1;
          setCombo(newCombo);
          setLastWordIndex(boundary + 1);
          
          // Add bonus time based on difficulty
          const bonusTime = getBonusTime();
          if (bonusTime > 0) {
            setTimeRemaining(prev => prev + bonusTime);
            setBonusTimeGained(prev => prev + bonusTime);
            
            // Show popup notification
            addPopupNotification(bonusTime, "bonus");
          }
        } else {
          // Word has errors - subtract penalty time and update word index
          setLastWordIndex(boundary + 1);
          
          // Subtract penalty time based on difficulty
          const penaltyTime = getPenaltyTime();
          if (penaltyTime > 0) {
            setTimeRemaining(prev => Math.max(prev - penaltyTime, 1)); // Don't go below 1 second
            
            // Show popup notification
            addPopupNotification(penaltyTime, "penalty");
          }
        }
        break;
      }
    }
  };
  
  const getBonusTime = () => {
    switch (gameSettings.difficulty) {
      case "easy": return 5;
      case "medium": return 3;
      case "hard": return 1;
      default: return 0;
    }
  };
  
  const getPenaltyTime = () => {
    switch (gameSettings.difficulty) {
      case "easy": return 1;
      case "medium": return 2;
      case "hard": return 3;
      default: return 0;
    }
  };

  const captureScreenshot = async () => {
    if (!resultsRef.current) return;
    
    try {
      const canvas = await html2canvas(resultsRef.current, {
        backgroundColor: '#ffffff',
        scale: 2, // Higher quality
        useCORS: true,
        allowTaint: true
      });
      
      // Convert to blob and download
      canvas.toBlob((blob) => {
        if (blob) {
          const url = URL.createObjectURL(blob);
          const link = document.createElement('a');
          link.href = url;
          link.download = `typeblast-results-${Date.now()}.png`;
          document.body.appendChild(link);
          link.click();
          document.body.removeChild(link);
          URL.revokeObjectURL(url);
          
          toast({
            title: "Screenshot saved!",
            description: "Your typing results have been downloaded as an image."
          });
        }
      }, 'image/png');
    } catch (error) {
      toast({
        title: "Screenshot failed",
        description: "Could not capture screenshot. Please try again.",
        variant: "destructive"
      });
    }
  };

  const renderText = () => {
    return textToType.split("").map((char, index) => {
      let className = "char-pending";
      
      if (index < userInput.length) {
        className = userInput[index] === char ? "char-correct" : "char-incorrect";
      } else if (index === currentCharIndex) {
        className = "char-current";
      }
      
      return (
        <span key={index} className={className}>
          {char}
        </span>
      );
    });
  };

  const getPerformanceFeedback = () => {
    const { wpm, accuracy } = gameStats;
    const feedback = [];
    
    if (wpm >= 40) {
      feedback.push("Great consistency in typing rhythm!");
    } else {
      feedback.push("Try to maintain a steady typing pace.");
    }
    
    if (accuracy < 95) {
      feedback.push("Focus on reducing errors to improve accuracy.");
    } else {
      feedback.push("Excellent accuracy! Keep it up.");
    }
    
    feedback.push("Try practicing with longer texts to build endurance.");
    
    return feedback;
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white shadow-sm border-b border-gray-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center">
              <Keyboard className="text-primary text-2xl mr-3" />
              <h1 className="text-xl font-bold text-gray-900">TypeBlast</h1>
            </div>
            <div className="flex items-center space-x-4">
              <Link href="/leaderboard">
                <Button variant="ghost" size="sm" data-testid="button-leaderboard">
                  <Trophy className="h-4 w-4" />
                  <span className="ml-2 hidden sm:inline">Leaderboard</span>
                </Button>
              </Link>
              <Button 
                variant="ghost" 
                size="sm" 
                onClick={() => setShowSettings(true)}
                data-testid="button-settings"
              >
                <Settings className="h-4 w-4" />
                <span className="ml-2 hidden sm:inline">Settings</span>
              </Button>
            </div>
          </div>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Game Setup */}
        {gameState === "setup" && (
          <div className="mb-8">
            <Card className="p-8">
              <div className="text-center mb-8">
                <h2 className="text-3xl font-bold text-gray-900 mb-4">Test Your Typing Speed</h2>
                <p className="text-lg text-gray-600">Choose your difficulty and start typing to improve your WPM!</p>
              </div>

              {/* Player Name Input */}
              <div className="mb-8">
                <Card className="p-6 bg-gradient-to-r from-blue-50 to-indigo-50 border-blue-200">
                  <div className="text-center">
                    <UserCircle className="h-8 w-8 text-blue-600 mx-auto mb-3" />
                    <h3 className="text-lg font-semibold text-gray-900 mb-2">Enter Your Name</h3>
                    <p className="text-sm text-gray-600 mb-4">Your name will appear on the leaderboard!</p>
                    <Input
                      type="text"
                      placeholder="Enter your name (optional)"
                      value={playerName}
                      onChange={(e) => {
                        const value = e.target.value;
                        // Limit to 24 characters
                        if (value.length <= 24) {
                          setPlayerName(value);
                        }
                      }}
                      maxLength={24}
                      className="max-w-md mx-auto"
                      data-testid="input-player-name"
                    />
                  </div>
                </Card>
              </div>
              
              <div className="grid md:grid-cols-3 gap-6 mb-8">
                {/* Difficulty Selection */}
                <div className="space-y-4">
                  <h3 className="text-lg font-semibold text-gray-900">Difficulty Level</h3>
                  <RadioGroup
                    value={gameSettings.difficulty}
                    onValueChange={(value: "easy" | "medium" | "hard") => 
                      setGameSettings(prev => ({ ...prev, difficulty: value }))
                    }
                    data-testid="radio-difficulty"
                  >
                    <div className="flex items-center space-x-2 p-4 bg-gray-50 rounded-lg hover:bg-gray-100">
                      <RadioGroupItem value="easy" id="easy" />
                      <Label htmlFor="easy" className="flex-1 cursor-pointer">
                        <div className="font-medium text-gray-900">Easy</div>
                        <div className="text-sm text-gray-500">Common words, 1 minute</div>
                      </Label>
                    </div>
                    <div className="flex items-center space-x-2 p-4 bg-gray-50 rounded-lg hover:bg-gray-100">
                      <RadioGroupItem value="medium" id="medium" />
                      <Label htmlFor="medium" className="flex-1 cursor-pointer">
                        <div className="font-medium text-gray-900">Medium</div>
                        <div className="text-sm text-gray-500">Mixed text, 2 minutes</div>
                      </Label>
                    </div>
                    <div className="flex items-center space-x-2 p-4 bg-gray-50 rounded-lg hover:bg-gray-100">
                      <RadioGroupItem value="hard" id="hard" />
                      <Label htmlFor="hard" className="flex-1 cursor-pointer">
                        <div className="font-medium text-gray-900">Hard</div>
                        <div className="text-sm text-gray-500">Complex sentences, 3 minutes</div>
                      </Label>
                    </div>
                  </RadioGroup>
                </div>

                {/* Test Type */}
                <div className="space-y-4">
                  <h3 className="text-lg font-semibold text-gray-900">Test Type</h3>
                  <RadioGroup
                    value={gameSettings.testType}
                    onValueChange={(value: "words" | "sentences" | "numbers") => 
                      setGameSettings(prev => ({ ...prev, testType: value }))
                    }
                    data-testid="radio-test-type"
                  >
                    <div className="flex items-center space-x-2 p-4 bg-gray-50 rounded-lg hover:bg-gray-100">
                      <RadioGroupItem value="words" id="words" />
                      <Label htmlFor="words" className="flex-1 cursor-pointer">
                        <div className="font-medium text-gray-900">Random Words</div>
                        <div className="text-sm text-gray-500">Individual words</div>
                      </Label>
                    </div>
                    <div className="flex items-center space-x-2 p-4 bg-gray-50 rounded-lg hover:bg-gray-100">
                      <RadioGroupItem value="sentences" id="sentences" />
                      <Label htmlFor="sentences" className="flex-1 cursor-pointer">
                        <div className="font-medium text-gray-900">Sentences</div>
                        <div className="text-sm text-gray-500">Full sentences</div>
                      </Label>
                    </div>
                    <div className="flex items-center space-x-2 p-4 bg-gray-50 rounded-lg hover:bg-gray-100">
                      <RadioGroupItem value="numbers" id="numbers" />
                      <Label htmlFor="numbers" className="flex-1 cursor-pointer">
                        <div className="font-medium text-gray-900">Numbers</div>
                        <div className="text-sm text-gray-500">Numeric sequences</div>
                      </Label>
                    </div>
                  </RadioGroup>
                </div>

                {/* Duration */}
                <div className="space-y-4">
                  <h3 className="text-lg font-semibold text-gray-900">Duration</h3>
                  <div className="grid grid-cols-2 gap-3">
                    {[60, 120, 180, 300].map((duration) => (
                      <Button
                        key={duration}
                        variant={gameSettings.duration === duration ? "default" : "outline"}
                        onClick={() => setGameSettings(prev => ({ ...prev, duration }))}
                        data-testid={`button-duration-${duration}`}
                      >
                        {duration / 60} min
                      </Button>
                    ))}
                  </div>
                </div>
              </div>

              <div className="text-center">
                <Button 
                  size="lg" 
                  onClick={startGame}
                  className="px-8 py-4 text-lg"
                  data-testid="button-start-game"
                >
                  <Play className="mr-2" />
                  Start Typing Test
                </Button>
              </div>
            </Card>
          </div>
        )}

        {/* Typing Interface */}
        {gameState === "playing" && (
          <div className="grid lg:grid-cols-4 gap-8">
            {/* Stats Panel */}
            <div className="lg:col-span-1 space-y-6">
              {/* Timer */}
              <Card className="p-6">
                <div className="text-center">
                  <h3 className="text-sm font-medium text-gray-500 mb-2">Time Remaining</h3>
                  <div className="text-4xl font-bold text-primary mb-4" data-testid="text-time-remaining">
                    {Math.floor(timeRemaining / 60)}:{(timeRemaining % 60).toString().padStart(2, '0')}
                  </div>
                  <Progress 
                    value={(timeRemaining / gameSettings.duration) * 100} 
                    className="w-full h-2"
                    data-testid="progress-time"
                  />
                </div>
              </Card>

              {/* Live Stats */}
              <Card className="p-6">
                <h3 className="text-lg font-semibold text-gray-900 mb-4">Live Stats</h3>
                <div className="space-y-4">
                  <div className="flex justify-between items-center">
                    <span className="text-gray-600">WPM</span>
                    <span className="text-2xl font-bold text-primary" data-testid="text-current-wpm">
                      {gameStats.wpm}
                    </span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-gray-600">Accuracy</span>
                    <span className="text-2xl font-bold text-green-600" data-testid="text-current-accuracy">
                      {gameStats.accuracy}%
                    </span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-gray-600">Errors</span>
                    <span className="text-2xl font-bold text-red-500" data-testid="text-error-count">
                      {gameStats.errors}
                    </span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-gray-600">Characters</span>
                    <span className="text-lg font-medium text-gray-900" data-testid="text-characters-typed">
                      {gameStats.totalCharacters}/{textToType.length}
                    </span>
                  </div>
                </div>
              </Card>

              {/* Combo Meter */}
              <Card className="p-6">
                <h3 className="text-lg font-semibold text-gray-900 mb-4">Combo Meter</h3>
                <div className="space-y-4">
                  <div className="text-center">
                    <div className="text-3xl font-bold text-primary mb-2" data-testid="text-combo-count">
                      {combo}x
                    </div>
                    <div className="text-sm text-gray-600">Word Streak</div>
                  </div>
                  {bonusTimeGained > 0 && (
                    <div className="text-center p-3 bg-green-50 border border-green-200 rounded-lg">
                      <div className="text-lg font-bold text-green-600" data-testid="text-bonus-time">
                        +{bonusTimeGained}s
                      </div>
                      <div className="text-xs text-green-600">Bonus Time Earned</div>
                    </div>
                  )}
                  <div className="text-center text-sm text-gray-500">
                    {gameSettings.difficulty === "easy" && (
                      <div>
                        <div className="text-green-600">+5s per correct word</div>
                        <div className="text-red-500">-1s per wrong word</div>
                      </div>
                    )}
                    {gameSettings.difficulty === "medium" && (
                      <div>
                        <div className="text-green-600">+3s per correct word</div>
                        <div className="text-red-500">-2s per wrong word</div>
                      </div>
                    )}
                    {gameSettings.difficulty === "hard" && (
                      <div>
                        <div className="text-green-600">+1s per correct word</div>
                        <div className="text-red-500">-3s per wrong word</div>
                      </div>
                    )}
                  </div>
                </div>
              </Card>

              {/* Progress */}
              <Card className="p-6">
                <h3 className="text-lg font-semibold text-gray-900 mb-4">Progress</h3>
                <div className="space-y-3">
                  <div className="flex justify-between text-sm text-gray-600">
                    <span>Completion</span>
                    <span data-testid="text-progress-percentage">
                      {Math.round((userInput.length / textToType.length) * 100)}%
                    </span>
                  </div>
                  <Progress 
                    value={(userInput.length / textToType.length) * 100}
                    className="w-full h-3"
                    data-testid="progress-completion"
                  />
                </div>
              </Card>
            </div>

            {/* Typing Area */}
            <div className="lg:col-span-3 relative">
              {/* Popup Notifications */}
              <div className="absolute -right-4 top-1/2 -translate-y-1/2 z-10 space-y-2 pointer-events-none">
                {popupNotifications.map((notification) => (
                  <div
                    key={notification.id}
                    className={`
                      px-4 py-2 rounded-lg font-bold text-lg shadow-lg
                      animate-[slideInRight_0.3s_ease-out,fadeOut_0.5s_ease-in_1.5s]
                      ${notification.type === "bonus" 
                        ? "bg-green-500 text-white" 
                        : "bg-red-500 text-white"
                      }
                    `}
                    data-testid={`popup-${notification.type}`}
                  >
                    {notification.type === "bonus" ? "+" : "-"}{notification.value}s
                  </div>
                ))}
              </div>
              
              <Card className="p-8">
                <div className="mb-6">
                  <div className="flex justify-between items-center mb-4">
                    <h3 className="text-lg font-semibold text-gray-900">Type the text below</h3>
                    <Button variant="ghost" onClick={resetGame} data-testid="button-reset">
                      <RotateCcw className="mr-2 h-4 w-4" />
                      Reset
                    </Button>
                  </div>
                </div>

                {/* Text Display */}
                <div className="mb-8">
                  <div className="bg-gray-50 rounded-lg p-6 text-xl leading-relaxed font-mono select-none typing-text" data-testid="text-display">
                    {renderText()}
                  </div>
                </div>

                {/* Input Area */}
                <div className="space-y-4">
                  <Textarea
                    ref={inputRef}
                    value={userInput}
                    onChange={(e) => handleInputChange(e.target.value)}
                    className="w-full h-32 p-4 text-xl font-mono resize-none typing-input"
                    placeholder="Start typing here..."
                    spellCheck={false}
                    autoComplete="off"
                    data-testid="input-typing"
                  />
                  
                  <div className="flex justify-between items-center text-sm text-gray-500">
                    <span>Press Ctrl+R to restart</span>
                    <span>Backspace to correct errors</span>
                  </div>
                </div>
              </Card>
            </div>
          </div>
        )}

        {/* Results Modal */}
        <Dialog open={showResults} onOpenChange={setShowResults}>
          <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
            <div ref={resultsRef}>
              <DialogHeader>
              <div className="text-center mb-8">
                <div className="inline-flex items-center justify-center w-16 h-16 bg-green-500 rounded-full mb-4">
                  <Trophy className="text-white text-2xl" />
                </div>
                <DialogTitle className="text-3xl font-bold text-gray-900 mb-2">Test Complete!</DialogTitle>
                <p className="text-gray-600">Here are your typing results</p>
              </div>
            </DialogHeader>

            <div className="grid md:grid-cols-2 gap-6 mb-8">
              {/* Primary Stats */}
              <div className="space-y-6">
                <Card className="text-center p-6 bg-primary/5 border-primary/20">
                  <div className="text-4xl font-bold text-primary mb-2" data-testid="text-final-wpm">
                    {gameStats.wpm}
                  </div>
                  <div className="text-sm font-medium text-gray-600">Words Per Minute</div>
                </Card>
                
                <Card className="text-center p-6 bg-green-500/5 border-green-500/20">
                  <div className="text-4xl font-bold text-green-600 mb-2" data-testid="text-final-accuracy">
                    {gameStats.accuracy}%
                  </div>
                  <div className="text-sm font-medium text-gray-600">Accuracy</div>
                </Card>
              </div>

              {/* Secondary Stats */}
              <div className="space-y-4">
                <div className="flex justify-between items-center p-4 bg-gray-50 rounded-lg">
                  <span className="text-gray-600">Total Characters</span>
                  <span className="font-semibold text-gray-900" data-testid="text-total-characters">
                    {gameStats.totalCharacters}
                  </span>
                </div>
                <div className="flex justify-between items-center p-4 bg-gray-50 rounded-lg">
                  <span className="text-gray-600">Correct Characters</span>
                  <span className="font-semibold text-green-600" data-testid="text-correct-characters">
                    {gameStats.correctCharacters}
                  </span>
                </div>
                <div className="flex justify-between items-center p-4 bg-gray-50 rounded-lg">
                  <span className="text-gray-600">Errors</span>
                  <span className="font-semibold text-red-500" data-testid="text-error-characters">
                    {gameStats.errors}
                  </span>
                </div>
                <div className="flex justify-between items-center p-4 bg-gray-50 rounded-lg">
                  <span className="text-gray-600">Time Taken</span>
                  <span className="font-semibold text-gray-900" data-testid="text-time-taken">
                    {Math.floor(gameStats.timeElapsed / 60)}:{(gameStats.timeElapsed % 60).toString().padStart(2, '0')}
                  </span>
                </div>
                <div className="flex justify-between items-center p-4 bg-gray-50 rounded-lg">
                  <span className="text-gray-600">Actual Typing Time</span>
                  <span className="font-semibold text-blue-600" data-testid="text-actual-seconds">
                    {actualTimeElapsed}s
                  </span>
                </div>
                <div className="flex justify-between items-center p-4 bg-gray-50 rounded-lg">
                  <span className="text-gray-600">Difficulty</span>
                  <span className="font-semibold text-gray-900 capitalize" data-testid="text-test-difficulty">
                    {gameSettings.difficulty}
                  </span>
                </div>
              </div>
            </div>

            {/* Performance Feedback */}
            <Card className="mb-8 p-6 bg-gradient-to-r from-blue-50 to-indigo-50 border-blue-200">
              <h3 className="text-lg font-semibold text-gray-900 mb-3">Performance Analysis</h3>
              <div className="space-y-2 text-sm text-gray-700">
                {getPerformanceFeedback().map((feedback, index) => (
                  <div key={index} className="flex items-center">
                    {index === 0 && <CheckCircle className="text-green-500 mr-2 h-4 w-4" />}
                    {index === 1 && <Info className="text-blue-500 mr-2 h-4 w-4" />}
                    {index === 2 && <Lightbulb className="text-yellow-500 mr-2 h-4 w-4" />}
                    <span>{feedback}</span>
                  </div>
                ))}
              </div>
            </Card>

            {/* Action Buttons */}
            <div className="flex flex-col sm:flex-row gap-4">
              <Button 
                className="flex-1" 
                onClick={() => {
                  setShowResults(false);
                  startGame();
                }}
                data-testid="button-retry"
              >
                <RotateCcw className="mr-2 h-4 w-4" />
                Try Again
              </Button>
              <Button 
                variant="outline" 
                className="flex-1" 
                onClick={resetGame}
                data-testid="button-new-test"
              >
                <Plus className="mr-2 h-4 w-4" />
                New Test
              </Button>
              <Button 
                variant="outline" 
                className="flex-1"
                onClick={() => {
                  const playerDisplay = playerName.trim() ? `${playerName} scored` : "I scored";
                  const testTypeDisplay = gameSettings.testType === "words" ? "Words" : 
                                         gameSettings.testType === "sentences" ? "Sentences" : "Numbers";
                  const difficultyDisplay = gameSettings.difficulty.charAt(0).toUpperCase() + gameSettings.difficulty.slice(1);
                  
                  const shareText = `🎯 ${playerDisplay} ${gameStats.wpm} WPM with ${gameStats.accuracy}% accuracy on TypeBlast!
                  
📊 Test Details:
• Difficulty: ${difficultyDisplay}
• Type: ${testTypeDisplay}  
• Characters: ${gameStats.correctCharacters}/${gameStats.totalCharacters}
• Errors: ${gameStats.errors}
• Time: ${Math.floor(gameStats.timeElapsed / 60)}:${(gameStats.timeElapsed % 60).toString().padStart(2, '0')}

Try beating my score! 🚀`;
                  
                  if (navigator.share) {
                    navigator.share({ 
                      title: 'Type Speed Results', 
                      text: shareText 
                    });
                  } else {
                    navigator.clipboard.writeText(shareText);
                    toast({ 
                      title: "Copied to clipboard!", 
                      description: "Your typing results have been copied. Paste anywhere to share!"
                    });
                  }
                }}
                data-testid="button-share"
              >
                <Share className="mr-2 h-4 w-4" />
                Share
              </Button>

              {/* Screenshot Button */}
              <Button
                variant="outline"
                className="bg-blue-500 text-white hover:bg-blue-600 border-blue-500"
                onClick={captureScreenshot}
                data-testid="button-screenshot"
              >
                <Camera className="mr-2 h-4 w-4" />
                Screenshot
              </Button>
            </div>
            </div>
          </DialogContent>
        </Dialog>

        {/* Settings Modal */}
        <Dialog open={showSettings} onOpenChange={setShowSettings}>
          <DialogContent className="max-w-md">
            <DialogHeader>
              <DialogTitle className="text-2xl font-bold text-gray-900 dark:text-gray-100">Settings</DialogTitle>
            </DialogHeader>

            <div className="space-y-6 py-4">
              {/* Game Settings Reset */}
              <div className="flex items-center justify-between p-4 bg-gray-50 dark:bg-gray-800 rounded-lg">
                <div className="flex items-center space-x-3">
                  <RotateCcw className="h-5 w-5 text-gray-700 dark:text-gray-300" />
                  <div>
                    <div className="font-medium text-gray-900 dark:text-gray-100">Reset Game</div>
                    <div className="text-sm text-gray-500 dark:text-gray-400">
                      Return to setup screen
                    </div>
                  </div>
                </div>
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => {
                    setGameState("setup");
                    setShowSettings(false);
                  }}
                  data-testid="button-reset-game"
                >
                  Reset
                </Button>
              </div>
            </div>
          </DialogContent>
        </Dialog>
      </main>

      {/* Footer */}
      <footer className="bg-white border-t border-gray-200 mt-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          <div className="grid md:grid-cols-3 gap-8">
            <div className="md:col-span-2">
              <div className="flex items-center mb-4">
                <Keyboard className="text-primary text-2xl mr-3" />
                <h3 className="text-xl font-bold text-gray-900">Type Speed</h3>
              </div>
              <p className="text-gray-600 mb-4">
                Improve your typing speed and accuracy with our comprehensive typing tests. Track your progress and compete with others.
              </p>
            </div>
            <div>
              <h4 className="font-semibold text-gray-900 mb-4">Features</h4>
              <ul className="space-y-2 text-sm text-gray-600">
                <li><a href="#" className="hover:text-primary transition-colors">Speed Tests</a></li>
                <li><a href="#" className="hover:text-primary transition-colors">Accuracy Training</a></li>
                <li><a href="#" className="hover:text-primary transition-colors">Progress Tracking</a></li>
              </ul>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
}
