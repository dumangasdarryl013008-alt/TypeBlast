# TypeBlast - Speed Typing Game

## Overview

TypeBlast is a comprehensive speed typing game built with modern web technologies. The application helps users improve their typing speed and accuracy through various difficulty levels and test types. Users can test their WPM (Words Per Minute), track their progress, and challenge themselves with different text content including words, sentences, and numbers. The application features a clean, responsive interface with real-time feedback and detailed performance analytics.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture
- **React 18** with TypeScript for type-safe component development
- **Vite** as the build tool and development server for fast hot module replacement
- **Tailwind CSS** for utility-first styling with custom design system variables
- **shadcn/ui** component library built on Radix UI primitives for accessible, customizable components
- **React Hook Form** with Zod validation for form handling and validation
- **TanStack Query (React Query)** for server state management and caching
- **Wouter** for lightweight client-side routing
- Single Page Application (SPA) architecture with component-based design

### Backend Architecture
- **Express.js** server with TypeScript for API endpoints
- **RESTful API** design with structured error handling
- In-memory storage implementation with `MemStorage` class for development
- Modular route organization with centralized route registration
- Built-in logging middleware for API request monitoring
- Environment-based configuration for development and production modes

### Data Storage Solutions
- **Drizzle ORM** configured for PostgreSQL with type-safe database operations
- **Neon Database** serverless PostgreSQL for cloud-hosted database
- Database schema includes:
  - Users table for authentication (prepared for future implementation)
  - Typing tests table for performance tracking
  - Text content table for test materials
- Migration system using Drizzle Kit for schema management
- Fallback in-memory storage for development without database connection

### Game Logic Architecture
- Real-time typing detection with character-by-character comparison
- WPM calculation based on standard 5-character word measurement
- Accuracy tracking with error counting and correction detection
- Timer-based test sessions with configurable durations
- Progress tracking with visual feedback using progress bars
- Settings management for difficulty levels, test types, and duration

### Component Architecture
- Reusable UI components following atomic design principles
- Custom hooks for game state management and mobile detection
- Toast notifications for user feedback and error handling
- Modal dialogs for game results and settings configuration
- Responsive design optimized for desktop and mobile devices

### External Dependencies

#### UI and Styling
- **Radix UI** primitives for accessible component foundations
- **Tailwind CSS** for utility-first CSS framework
- **class-variance-authority** for component variant management
- **Lucide React** for consistent iconography
- **Inter font** from Google Fonts for typography

#### State Management and API
- **TanStack Query v5** for server state management and caching
- **React Hook Form** with **@hookform/resolvers** for form validation
- **Zod** for runtime type validation and schema definition
- **date-fns** for date manipulation and formatting

#### Database and ORM
- **Drizzle ORM** for type-safe database operations
- **Neon Database Serverless** for PostgreSQL hosting
- **Drizzle Kit** for database migrations and schema management
- **connect-pg-simple** for PostgreSQL session storage (prepared for auth)

#### Development Tools
- **Vite** for build tooling and development server
- **TypeScript** for static type checking
- **ESBuild** for production bundling
- **PostCSS** with Autoprefixer for CSS processing
- **Replit plugins** for development environment integration

#### Utility Libraries
- **clsx** and **tailwind-merge** for conditional CSS class management
- **nanoid** for unique ID generation
- **cmdk** for command palette functionality (future feature)
- **embla-carousel-react** for carousel components (future feature)