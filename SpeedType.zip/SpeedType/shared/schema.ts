import { sql } from "drizzle-orm";
import { pgTable, text, varchar, integer, real, timestamp, boolean } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const users = pgTable("users", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
});

export const typingTests = pgTable("typing_tests", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id"),
  playerName: text("player_name"), // For guest players and leaderboard display
  difficulty: text("difficulty").notNull(), // easy, medium, hard
  testType: text("test_type").notNull(), // words, sentences, numbers
  duration: integer("duration").notNull(), // in seconds
  wpm: real("wpm").notNull(),
  accuracy: real("accuracy").notNull(),
  totalCharacters: integer("total_characters").notNull(),
  correctCharacters: integer("correct_characters").notNull(),
  errorCount: integer("error_count").notNull(),
  completedAt: timestamp("completed_at").defaultNow(),
});

export const textContent = pgTable("text_content", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  difficulty: text("difficulty").notNull(),
  testType: text("test_type").notNull(),
  content: text("content").notNull(),
  isActive: boolean("is_active").default(true),
});

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
});

export const insertTypingTestSchema = createInsertSchema(typingTests).omit({
  id: true,
  completedAt: true,
});

export const insertTextContentSchema = createInsertSchema(textContent).omit({
  id: true,
});

export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;
export type TypingTest = typeof typingTests.$inferSelect;
export type InsertTypingTest = z.infer<typeof insertTypingTestSchema>;
export type TextContent = typeof textContent.$inferSelect;
export type InsertTextContent = z.infer<typeof insertTextContentSchema>;
