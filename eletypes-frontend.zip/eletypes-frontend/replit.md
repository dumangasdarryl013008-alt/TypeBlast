# Ele Types - Elegant Typing Test Tool

## Overview
An elegant typing test website built with React (Create React App). Features multiple typing modes, themes, vocabulary learning tools, and a touch-typing trainer.

**Current State**: Successfully imported and configured for Replit environment
**Tech Stack**: React 18, Create React App, Material-UI, Recharts, Styled Components
**Last Updated**: October 8, 2025

## Project Structure
```
├── public/          # Static assets and HTML template
├── src/
│   ├── assets/      # Sounds, vocab data, images
│   ├── components/  # React components
│   │   ├── common/  # Shared components
│   │   └── features/# Feature-specific components
│   ├── constants/   # App constants and data
│   ├── hooks/       # Custom React hooks
│   ├── scripts/     # Utility scripts
│   ├── style/       # Theme and global styles
│   └── worker/      # Web workers for performance
└── package.json     # Dependencies and scripts
```

## Key Features
1. **Typing Test**: Words and sentence modes with stats (WPM, accuracy, errors)
2. **Vocabulary Cards**: GRE, TOEFL, CET4/6 word lists for learning
3. **Touch-Typing Trainer**: QWERTY keyboard trainer
4. **Themes**: 13+ static themes + 4 dynamic WebGL themes
5. **Sound Effects**: Cherry blue, keyboard, typewriter sounds
6. **Music Integration**: Spotify player support
7. **Modes**: Focus mode, Ultra Zen mode, Coffee (free typing) mode

## Development Setup

### Running the App
- **Development Server**: `npm start` (configured for port 5000)
- **Build**: `npm run build`
- **Test**: `npm run test`

### Replit Configuration
- Port: 5000 (required for Replit)
- Host: 0.0.0.0 (allows Replit proxy)
- Host check disabled for iframe preview support
- WebSocket port: 0 (auto-detect)

## Environment Notes
- Uses localStorage for settings persistence (theme, game mode, sound preferences)
- No backend - fully client-side application
- No environment variables or API keys required
- Audio files and vocabulary data bundled in assets

## Recent Changes
- **2025-10-08**: Imported from GitHub and configured for Replit
  - Modified package.json start script to run on port 5000 with host 0.0.0.0
  - Disabled host check for Replit proxy compatibility
  - Set up development workflow
