import React from "react";
import { Box, Button, Tooltip } from "@mui/material";
import {
  GAME_MODE_NORMAL,
  GAME_MODE_HARD,
  GAME_MODE_SURVIVAL,
  GAME_MODE_COMBO,
} from "../../../constants/Constants";

const GameModeSelector = ({ gameMode, setGameMode, disabled }) => {
  const modes = [
    {
      value: GAME_MODE_NORMAL,
      label: "Normal",
      tooltip: "Standard typing mode",
    },
    {
      value: GAME_MODE_HARD,
      label: "Hard",
      tooltip: "-1 second for every wrong type",
    },
    {
      value: GAME_MODE_SURVIVAL,
      label: "Survival",
      tooltip: "-2s per wrong word, +1s per correct word",
    },
    {
      value: GAME_MODE_COMBO,
      label: "Combo",
      tooltip: "+3s for 2 consecutive correct words, -1s for wrong word",
    },
  ];

  return (
    <Box sx={{ display: "flex", gap: 1, flexWrap: "wrap", justifyContent: "center" }}>
      {modes.map((mode) => (
        <Tooltip key={mode.value} title={mode.tooltip}>
          <Button
            size="small"
            variant={gameMode === mode.value ? "contained" : "outlined"}
            onClick={() => setGameMode(mode.value)}
            disabled={disabled}
            sx={{
              minWidth: "70px",
              fontSize: { xs: "0.7rem", sm: "0.8rem" },
              padding: { xs: "4px 8px", sm: "6px 16px" },
            }}
          >
            {mode.label}
          </Button>
        </Tooltip>
      ))}
    </Box>
  );
};

export default GameModeSelector;
