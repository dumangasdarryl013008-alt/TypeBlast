import React from "react";
import KeyboardAltIcon from "@mui/icons-material/KeyboardAlt";
import { Box, TextField } from "@mui/material";

const Logo = ({ isFocusedMode, playerName, setPlayerName }) => {

  return (
    <div className="header" style={{visibility: isFocusedMode ? 'hidden' : 'visible' }}>
      <Box display="flex" justifyContent="space-between" alignItems="center" width="100%">
        <Box>
          <h1>
            TypeBlast <KeyboardAltIcon fontSize="large" />
          </h1>
          <span className="sub-header">
            an elegant typing experience, just start typing
          </span>
        </Box>
        <Box>
          <TextField
            variant="outlined"
            size="small"
            placeholder="Enter your name"
            value={playerName}
            onChange={(e) => setPlayerName(e.target.value)}
            sx={{
              input: { color: 'inherit' },
              '& .MuiOutlinedInput-root': {
                '& fieldset': {
                  borderColor: 'currentColor',
                },
                '&:hover fieldset': {
                  borderColor: 'currentColor',
                },
                '&.Mui-focused fieldset': {
                  borderColor: 'currentColor',
                },
              },
            }}
          />
        </Box>
      </Box>
    </div>
  );
};

export default Logo;
